package com.plcoding.weatherapp.presentation.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBlue = Color(0xFF1B3B5A)
val DeepBlue = Color(0xFF102840)